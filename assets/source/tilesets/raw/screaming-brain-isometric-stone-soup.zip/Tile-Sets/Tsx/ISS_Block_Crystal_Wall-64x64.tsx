<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ISS_Block_Crystal_Wall-64x64" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="../Walls/Block/ISS_Block_Crystal_Wall-64x64.png" trans="ff00ff" width="512" height="512"/>
</tileset>
